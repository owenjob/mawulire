from . import db
from sqlalchemy.sql import func


class Posts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), unique=True)
    post = db.Column(db.String(150))
    date_created = db.Column(db.DateTime(timezone=True), default=func.now())