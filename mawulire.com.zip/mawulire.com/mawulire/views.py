
from genericpath import exists
from turtle import title
from flask import Blueprint, render_template, request, flash
from . import db
from .models import Posts

views = Blueprint('views', __name__)

@views.route('/',methods=['GET', 'POST'])
def home():
    if request.method == "POST":
        search1 = request.form.get('search')
        print(search1)
        
        posts = Posts.query.filter_by(title=search1)
        post = Posts.query
        post = post.filter(Posts.title.like('%' + search1 + '%'))
        post = post.order_by(Posts.title).all()
        if posts:
            flash('we found the following', category='success')
        print(posts)
        return render_template("home.html",posts=posts ,post=post, search1=search1)
    #posts = Posts.query.all()
    return render_template("home.html")

@views.route('/addpost',methods=['GET', 'POST'])
def addpost():
    if request.method == "POST":
        title = request.form.get('title')
        post = request.form.get('post')

        if len(title) < 0:
            flash('Add Title', category='error')
        elif len(post) < 0:
            flash('Add Post', category='error')
        else:
            new_post = Posts(title=title, post=post)
            db.session.add(new_post)
            db.session.commit()
            flash('Post added!', category='success')
    return render_template('addposts.html')

@views.route('/post/<title>')
def posts(title):
    title2 = Posts.query.filter_by(title=title).first()
    print(title2)

    return render_template('posts.html',title=title, title2=title2)
